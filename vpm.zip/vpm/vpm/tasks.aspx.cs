﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace vpm
{
    public partial class tasks : System.Web.UI.Page
    {
        SqlConnection db = null;
        string con = "";
        String company = "", uid = "", uuid = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uid"] != null)
            {
                uid = Session["uid"].ToString();
                company = Session["company"].ToString();
                try
                {
                    con = "Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=pm;User ID=kalash;Password=1904";
                    db = new SqlConnection(con);
                    task.NavigateUrl = "tasks.aspx?pid="+Request.QueryString["pid"];
                    profile.Text = "Kalash";
                    members.NavigateUrl = "members.aspx?pid=" + Request.QueryString["pid"];
                }
                catch (SqlException se)
                {
                    Response.Write(se);
                }
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
                
        }

        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void SqlDataSource3_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
    }
}