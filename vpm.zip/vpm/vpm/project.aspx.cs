﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace vpm
{
    public partial class project : System.Web.UI.Page
    {
        SqlConnection db = null;
        string con = "";
        String company = "", uid = "", uuid = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uid"] != null)
            {
                uid = Session["uid"].ToString();
                company = Session["company"].ToString();
                try
                {
                    con = "Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=pm;User ID=kalash;Password=1904";
                    db = new SqlConnection(con);
                    task.NavigateUrl = "tasks.aspx?pid=" + Request.QueryString["pid"];
                    member.NavigateUrl = "members.aspx?pid=" + Request.QueryString["pid"];

                }
                catch (SqlException se)
                {
                    Response.Write(se);
                }
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Redirect("members.aspx?pid=" + GridView1.SelectedRow.Cells[0].Text);
        }

        protected void add_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=pm;User ID=kalash;Password=1904");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into projects (pname,uid) values('" + TBname.Text + "', "+ uid +" );", con);
            cmd.ExecuteNonQuery();

            string select = "SELECT TOP 1 * FROM projects ORDER BY pid DESC ";
            SqlCommand sel = new SqlCommand(select, con);
            SqlDataReader dr = sel.ExecuteReader();
            dr.Read();
            int pid = (Int32)dr.GetValue(0);
            dr.Close();

            SqlCommand insert = new SqlCommand("insert into members (pid,uid) values('" + pid + "', " + uid + " );", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("project.aspx");
        }

        protected void new_Click(object sender, EventArgs e)
        {
            TBname.Visible = true;
            name.Visible = true;
            add.Visible = true;
            title.Visible = true;
        }
    }
}