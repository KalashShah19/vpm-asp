﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            int uid,login = 0;
            String first,company;
            String mail = email.Text, pass = password.Text;
            try{
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=pm;User ID=kalash;Password=1904");
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from users;", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while(dr.Read()){
                    if (mail.Equals(dr.GetString(3)) && pass.Equals(dr.GetString(4)))
                    {
                        login = 1;
                        uid = dr.GetInt32(0);
                        first = dr.GetString(2);
                        company = dr.GetString(7);
                        Session.Add("uid", uid);
                        Session.Add("fname", first);
                        Session.Add("company", company);
                        break;
                    }
                    else {
                    }
                }

                if (login == 1) {
                    Response.Redirect("members.aspx");
                }
                else {
                    Response.Write("<script> alert('Login Failed!'); </script>");
                }

                con.Close();
            }
            catch(SqlException se){
                Response.Write(se);
            }
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

    }
}