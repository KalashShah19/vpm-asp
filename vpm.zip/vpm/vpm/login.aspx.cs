﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpCookie c = Request.Cookies["login"];
                if (c != null)
                {
                    email.Text = c["email"];
                    password.Attributes["value"] = c["password"];
                }

            }


        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            int uid=0,login = 0;
            String first,company;
            String mail = email.Text, pass = password.Text;
            try{
                SqlConnection con = new SqlConnection("Data Source=LAPTOP-VCRMDHGE\\SQLEXPRESS;Initial Catalog=pm;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("select uid,fname,company from users where email = '"+mail+"'and password = '"+pass+"';", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows){
                    dr.Read();
                    login = 1;
                    uid = dr.GetInt32(0);
                    first = dr.GetString(1);
                    company = dr.GetString(2);
                    Session.Add("uid", uid);
                    Session.Add("fname", first);
                    Session.Add("company", company);

                    if (CheckBox1.Checked)
                    {
                        HttpCookie c = new HttpCookie("login");
                        c.Values.Add("email", mail);
                        c.Values.Add("password", pass);
                        Response.Cookies.Add(c);
                    }
                }
                else {
                    Response.Write("Login Failed");
                }

                if (login == 1) {
                    Response.Redirect("project.aspx");
                }
                else {
                    Response.Write("<script> alert('Login Failed!'); </script>");
                }

                con.Close();
            }
            catch(SqlException se){
                Response.Write(se);
            }
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}