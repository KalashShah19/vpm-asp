﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            int uid,login = 0;
            String first;
            String mail = email.Text, pass = password.Text;
            SqlConnection con = new SqlConnection("");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from UserInformation;", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read()){
                if (mail.Equals(dr.GetString(1)) && pass.Equals(dr.GetString(2)))
                {
                    login = 1;
                    uid = dr.GetInt32(1);
                    first = dr.GetString(2);
                    Session.Add("uid", uid);
                    Session.Add("fname", first);
                }
                else {
                    login = 0;
                }
            }

            if (login == 1) {
                Response.Redirect("home.aspx");
            }
            else {
                Response.Write("<script> alert('Login Failed!'); </script>");
            }

            con.Close();
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

    }
}