﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            int reg = -1;
            String pass = password.Text, cpass = confirm.Text;
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-VCRMDHGE\\SQLEXPRESS;Initial Catalog=pm;Integrated Security=True");
            con.Open();
            if (pass.Equals(cpass)) {
                reg = 1;
            }
            else {
                reg = 0;
            }

            SqlCommand cmd = new SqlCommand("insert into user (fname, lname, email, number, password, company, designation) values('" + fname.Text + "', '" + lname.Text + "','" + email.Text + "','" + number.Text + "','" + password.Text + "','" + company.Text + "','" + designation.Text + "',);", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}