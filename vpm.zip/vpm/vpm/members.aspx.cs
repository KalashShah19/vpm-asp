﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class members : System.Web.UI.Page
    {
        SqlConnection db = null;
        string con = "";
        String company="",uid="",uuid="";

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();

            if (Session["uid"] != null)
            {
                uid = Session["uid"].ToString();
                company = Session["company"].ToString();
                try {
                    con = "Data Source=LAPTOP-VCRMDHGE\\SQLEXPRESS;Initial Catalog=pm;Integrated Security=True";
                    db = new SqlConnection(con);
                    task.NavigateUrl = "tasks.aspx?pid=" + Request.QueryString["pid"];
                    member.NavigateUrl = "members.aspx?pid=" + Request.QueryString["pid"];
                    
                }
                catch(SqlException se){
                    Response.Write(se);
                }
            }
            else {
                Response.Redirect("login.aspx");
            }
        }

        protected void users_SelectedIndexChanged(object sender, EventArgs e)
        {
            fname.Text = users.SelectedRow.Cells[2].Text;
            lname.Text = users.SelectedRow.Cells[3].Text;
            email.Text = users.SelectedRow.Cells[4].Text;
            number.Text = users.SelectedRow.Cells[5].Text;         
            designation.Text = users.SelectedRow.Cells[6].Text;
            label.Text = "Edit Member";
            password.Visible = false;
            confirm.Visible = false;
            lblconfirm.Visible = false;
            lblpassword.Visible = false;
            btn_update.Visible = true;
            btn_add.Visible = false;
            
        }

        protected void btn_add_Click(object sender, EventArgs e)
        {
            try{
                db.Open();
                string insert = "insert into users(fname,lname,number,email, designation, password,company) values ('"+fname.Text+"','"+lname.Text+"','"+number.Text+"','"+email.Text+"', '" + designation.Text+"', '"+ password.Text+"', '" + company + "')";
                SqlCommand cmd = new SqlCommand(insert, db);
                int a = cmd.ExecuteNonQuery();

                string select = "SELECT TOP 1 * FROM users ORDER BY uid DESC ";
                SqlCommand sel = new SqlCommand(select, db);
                int nuid = 0;
                SqlDataReader dr = sel.ExecuteReader();
                dr.Read();
                nuid = (Int32)dr.GetValue(0);
                dr.Close();

                string insert2 = "insert into members (pid, uid) values(" + Request.QueryString["pid"] + "," + nuid +");";
                SqlCommand cmd2 = new SqlCommand(insert2, db);
                int b = cmd2.ExecuteNonQuery();

                if (a != 0 && b != 0)
                {

                    Response.Write("<script>alert('Member Added!!')</script>");
                    Response.Redirect("members.aspx?pid=" + Request.QueryString["pid"]);
                    db.Close();
                }
                else
                {
                    Response.Write("Failed");
                }
             }
            catch(SqlException se){
                Response.Write(se);
            }   
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                uuid = users.SelectedRow.Cells[1].Text;
                Response.Write("<script> alert("+uuid+"); </script>");
                db.Open();
                string insert = "update users set fname = '"+fname.Text+"', lname='"+lname.Text+"',email='"+email.Text+"',number='"+number.Text+"',designation='"+designation.Text+"' where uid="+uuid+";";
                SqlCommand cmd = new SqlCommand(insert, db);
                int m = cmd.ExecuteNonQuery();
                if (m != 0)
                {
                    Response.Write("<script>alert('Member Updated!!')</script>");
                    Response.Redirect("members.aspx?pid=" + Request.QueryString["pid"]);
                }
                else
                {
                    Response.Write("<script>alert('Failed !!')</script>");
                }
                db.Close();
            }
            catch (SqlException se)
            {
                Response.Write(se);
            }   
        }
    }
}