﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace vpm
{
    public partial class members : System.Web.UI.Page
    {
        SqlConnection db = null;
        string con = "";
        String company="",uid="",uuid="";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uid"] != null)
            {
                uid = Session["uid"].ToString();
                company = Session["company"].ToString();
                try {
                    con = "Data Source=DESKTOP-K4C46LA\\SQLEXPRESS;Initial Catalog=pm;User ID=kalash;Password=1904";
                    db = new SqlConnection(con);
                }
                catch(SqlException se){
                    Response.Write(se);
                }
            }
            else {
                Response.Redirect("login.aspx");
            }
        }

        protected void users_SelectedIndexChanged(object sender, EventArgs e)
        {
            uuid = users.SelectedRow.Cells[0].Text;
            fname.Text = users.SelectedRow.Cells[1].Text;
            lname.Text = users.SelectedRow.Cells[2].Text;
            email.Text = users.SelectedRow.Cells[3].Text;
            number.Text = users.SelectedRow.Cells[4].Text;         
            designation.Text = users.SelectedRow.Cells[5].Text;
            label.Text = "Edit Member";
            password.Visible = false;
            confirm.Visible = false;
            lblconfirm.Visible = false;
            lblpassword.Visible = false;
            btn_update.Visible = true;
            btn_add.Visible = false;
        }

        protected void btn_add_Click(object sender, EventArgs e)
        {
            try{  
                db.Open();  
                string insert = "insert into users(fname,lname,number,email, designation, password,company) values ('"+fname.Text+"','"+lname.Text+"','"+number.Text+"','"+email.Text+"', '" + designation.Text+"', '"+ password.Text+"', '" + company + "')";  
                SqlCommand cmd = new SqlCommand(insert,db);  
                int m = cmd.ExecuteNonQuery();  
                if(m != 0)  
                {  
                   Response.Write("<script>alert('Member Added!!')</script>");
                   Response.Redirect("members.aspx");
                }  
                else  
                {  
                   Response.Write("<script>alert('Failed !!')</script>");  
                }  
                db.Close(); 
             }
            catch(SqlException se){
                Response.Write(se);
            }   
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Write(uuid);
                db.Open();
                string insert = "update users set fname = '"+fname.Text+"', lname='"+lname.Text+"',email='"+email.Text+"',number='"+number.Text+"',designation='"+designation.Text+"' where uid="+uuid+";";
                SqlCommand cmd = new SqlCommand(insert, db);
                int m = cmd.ExecuteNonQuery();
                if (m != 0)
                {
                    Response.Write("<script>alert('Member Updated!!')</script>");
                    Response.Redirect("members.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Failed !!')</script>");
                }
                db.Close();
            }
            catch (SqlException se)
            {
                Response.Write(se);
            }   
        }
    }
}