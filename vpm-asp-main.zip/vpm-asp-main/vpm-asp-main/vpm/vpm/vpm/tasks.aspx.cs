﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace vpm
{
    public partial class tasks : System.Web.UI.Page
    {
        SqlConnection db = null;
        string con = "";
        String company = "", uid = "", uuid = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();

            if (Session["uid"] != null)
            {
                uid = Session["uid"].ToString();
                company = Session["company"].ToString();
                try
                {
                    con = "Data Source=LAPTOP-VCRMDHGE\\SQLEXPRESS;Initial Catalog=pm;Integrated Security=True";
                    db = new SqlConnection(con);
                    task.NavigateUrl = "tasks.aspx?pid="+Request.QueryString["pid"];
                    members.NavigateUrl = "members.aspx?pid=" + Request.QueryString["pid"];
                }
                catch (SqlException se)
                {
                    Response.Write(se);
                }
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
                
        }

        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void SqlDataSource3_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
    }
}